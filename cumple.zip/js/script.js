document.addEventListener("DOMContentLoaded", () => {
    const chapters = document.querySelectorAll(".hero__section");
    const btnPrev = document.getElementById("btn-prev");
    const btnNext = document.getElementById("btn-next");
    let currentChapterIndex = 0;

    function updateChapters() {
        // Mostrar únicamente el capítulo actual
        chapters.forEach((chapter, index) => {
            if (index === currentChapterIndex) {
                chapter.classList.add("active");
            } else {
                chapter.classList.remove("active");
            }
        });

        // Habilitar o deshabilitar botones según la posición
        btnPrev.disabled = currentChapterIndex === 0;
        btnNext.disabled = currentChapterIndex === chapters.length - 1;
    }

    btnNext.addEventListener("click", () => {
        if (currentChapterIndex < chapters.length - 1) {
            currentChapterIndex++;
            updateChapters();
        }
    });

    btnPrev.addEventListener("click", () => {
        if (currentChapterIndex > 0) {
            currentChapterIndex--;
            updateChapters();
        }
    });

    // Inicializar visualización
    updateChapters();
});